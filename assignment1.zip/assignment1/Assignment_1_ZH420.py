import random

userList = []

#Loop to populate the list of values entered by user until stop is entered
while True:
    print("Enter 'stop' to exit. ")
    userInput = input("Please enter some countries you would like to visit:")

    if userInput.capitalize() == "Stop":
        break
    else:
        userList.append(userInput.capitalize())



#Question 4
counter = 0

for i in userList:
    print(userList[counter], "is ", len(userList[counter]), "characters long.")
    counter += 1

#Question 5
randNum = random.randint(0, len(userList)-1)
#print("The index is " ,randNum)


#Question 6
charInput = input("Please try to guess a letter in the randomly selected word from the list: ")
index = userList[randNum]

# for i in index:
#     if charInput.lower() == i.lower():
#         print("The letter", charInput, " is in the word ", index)
#         break


if index.find(charInput) != -1:
    print("The letter", charInput, " is in the word ", index)

else:
    print("The letter", charInput, " is not in the word ", index)